</div><!-- /.container -->
<footer class="blog-footer">
      <p>&copy; <?php echo Date('Y'); ?> - <?php bloginfo('name'); ?></p>
      <p>
        <a href="#" class="blog-footer-link">Back to top</a>
      </p>
    </footer>
    <?php wp_footer(); ?>

  </body>
</html>
